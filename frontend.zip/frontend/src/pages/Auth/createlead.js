import axios from "axios";
import { useState } from "react";
import { toast, ToastContainer } from "react-toastify";

export default function Createlead (){

    const [name, setName] = useState("");
    const [email , setEmail] = useState("");
    const [phone , setPhone] = useState(0);

    const submit = () => {
        axios({
            method: 'get',
            url:'http://localhost:8000/sanctum/csrf-cookie',
            withCredentials:true,
            withXSRFToken:true,
        }).then(response => {
            console.log( response) 
        })
    
        
        axios({
            method: 'post',
            url:'http://localhost:8000/api/leads',
            withCredentials:true,
           headers:{
            'Content-Type':'application/json'
           },
            data: JSON.stringify({
                name : name,
                email : email,
                phone : phone
            })
        }).then(response => {
            console.log( response) 
            toast ("Lead has been added successfully")
           
        }).catch(error => {
            alert(error.response.data.message)
        })
    }

    return (

        <>
        {/**Laptops */}
            <div className="d-none d-sm-block">
                <h1> Create lead</h1>
                <hr />

                <div className="min-vh-100  d-flex flex-column" >
                
                    
                    <ToastContainer />
                    <div className="w-50 mx-auto my-auto bg-light rounded shadow-lg">
                    <img src="transaction.png" alt="our logo - kalangeneexafront"  className="d-block mx-auto my-3" width={70} height={70}/>
                    <p className="h3">Add lead</p>
                        <table  className="mx-auto" style={{ borderCollapse:'separate' , borderSpacing:'1em' }}>

                        <tr className="mt-3 form-group">
                                
                                <td className="text-end">
                                    <label htmlFor="useremail"  >Name</label>
                                </td>
                                <td>
                                    <input  type="text" id="useremail" className="form-control" value={name} onChange={(e) => {
                                        setName(e.target.value)
                                    }}/>
                                </td>
                            
                        </tr>

                            <tr className="mt-3 form-group">
                                
                                    <td className="text-end">
                                        <label htmlFor="useremail"  >Email</label>
                                    </td>
                                    <td>
                                        <input type="email" id="useremail" className="form-control"  value={email} onChange={(e) => {
                                            setEmail(e.target.value)
                                        }}/>
                                    </td>
                                
                            </tr>

                        

                            <tr className="mt-3 form-group">
                                
                                    <td className="text-end">
                                        <label htmlFor="password" >Phone</label>
                                    </td>
                                    <td>
                                        <input type="tel" id="password" className="form-control" value={phone}  onChange={(e) => {
                                            setPhone(e.target.value)
                                        }}/>
                                    </td>
                                    
                                
                            </tr>

                        

                            <tr className="mt-3 form-group">
                                <td></td>
                                <td><button type="submit" className="btn btn-primary btn-lg" onClick={() => {
                                    submit()
                                }}>Add Lead</button></td>
                            </tr>
                        </table>
                        </div>
                

                </div>
            </div>

            {/**Mobile phone  */}
            <div className="d-block d-sm-none">
                <h1> Create lead</h1>
                <hr />

                <div className="min-vh-100  " >
                
                    
                    <ToastContainer />
                    <div className="w-100 mx-auto my-auto bg-light rounded shadow-lg">
                    <img src="transaction.png" alt="our logo - kalangeneexafront"  className="d-block mx-auto my-3" width={70} height={70}/>
                    <p className="h3">Add lead</p>
                        <table  className="mx-auto" style={{ borderCollapse:'separate' , borderSpacing:'1em' }}>

                        <tr className="mt-3 form-group">
                                
                                <td className="text-end">
                                    <label htmlFor="useremail"  >Name</label>
                                </td>
                                <td>
                                    <input  type="text" id="useremail" className="form-control" value={name} onChange={(e) => {
                                        setName(e.target.value)
                                    }}/>
                                </td>
                            
                        </tr>

                            <tr className="mt-3 form-group">
                                
                                    <td className="text-end">
                                        <label htmlFor="useremail"  >Email</label>
                                    </td>
                                    <td>
                                        <input type="email" id="useremail" className="form-control"  value={email} onChange={(e) => {
                                            setEmail(e.target.value)
                                        }}/>
                                    </td>
                                
                            </tr>

                        

                            <tr className="mt-3 form-group">
                                
                                    <td className="text-end">
                                        <label htmlFor="password" >Phone</label>
                                    </td>
                                    <td>
                                        <input type="tel" id="password" className="form-control" value={phone}  onChange={(e) => {
                                            setPhone(e.target.value)
                                        }}/>
                                    </td>
                                    
                                
                            </tr>

                        

                            <tr className="mt-3 form-group">
                                <td></td>
                                <td><button type="submit" className="btn btn-primary btn-lg" onClick={() => {
                                    submit()
                                }}>Add Lead</button></td>
                            </tr>
                        </table>
                        </div>
                

                </div>
            </div>
        </>
        
    )
}