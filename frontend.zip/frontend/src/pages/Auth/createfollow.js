import axios from "axios"
import { useEffect, useState } from "react"
import { toast, ToastContainer } from "react-toastify"

export default function Createfollow (){
    const [ leads, setLeads] = useState([])
    

    useEffect(()=>{
        axios({
            method: 'get',
            url:'http://localhost:8000/sanctum/csrf-cookie',
            withCredentials:true,
            withXSRFToken:true,
        }).then(response => {
            console.log( response) 
        })

        axios({
            method: 'get',
            url:'http://localhost:8000/api/leads/all',
            withCredentials:true,
           headers:{
            'Content-Type':'application/json'
           },
            
        }).then(response => {
           
            setLeads(response.data)
            console.log(response.data)
            
        }).catch(error => {
            alert(error.response.data.message)
        })

    },[])


    return (
        <div>
            <h1> Schedule Follow</h1>
            <hr />
            {leads.length === 0? (
                <div className="alert alert-danger" role="alert">
                    <p>Leads appear in the section bellow. Proceed to add a lead in the "Add lead Section "</p>
                </div>
                ): (<> 
                {/** Laptop devices */}
                <table className="mx-auto table table-striped d-none d-sm-block ">
                    
                    <thead className="thead-dark">
                        <tr>
                            <th scope="col">Email</th>
                            <th scope="col">Schedule</th>
                            <th scope="col">Date time</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    </table>
                    {leads.map(function(lead){
                        return (
                            <>
                             <form onSubmit={(e)=>{
                                            e.preventDefault()
                                            console.log(e.target[0].value)
                                            console.log(e.target[1].value)
                                            axios({
                                                method: 'get',
                                                url:'http://localhost:8000/sanctum/csrf-cookie',
                                                withCredentials:true,
                                                withXSRFToken:true,
                                            }).then(response => {
                                                console.log( response) 
                                            })
                                    
                                            axios({
                                                method: 'post',
                                                url:'http://localhost:8000/api/followups',
                                                withCredentials:true,
                                               headers:{
                                                'Content-Type':'application/json'
                                               },
                                               data: {
                                                lead_id: e.target[0].value,
                                                scheduled_at: e.target[1].value,
                                               },
                                                
                                            }).then(response => {
                                               
                                               toast("Follow up has been scheduled")
                                                console.log(response.data)
                                                
                                            }).catch(error => {
                                                alert(error.response.data.message)
                                            }) 
                                        }} >
                                <table  className="mx-auto table table-striped d-none d-sm-block " >
                                <tr>
                                    <input type="hidden" value={lead.id} name="lead_id" id="ead_id"/>
                                    <td><p>{lead.email}</p></td>
                                    <td><label>Schedule followup</label></td> 
                                    <ToastContainer />
                                    <td><input type="datetime-local"  className="form-control" name="scheduled_at" id="scheduled_at"/></td> 
                                    <td>
                                        <button type="submit" className="btn d-flex btn-outline-dark align-items-center"
                                        
                                        >
                                            <img src="add.png" className="d-block" alt="add" width={20} height={20}/>
                                            submit
                                        </button>
                                    </td>                        
                                </tr>
                                </table>
                                
                                </form>  


 {/**Mobile phones */}
                                <form onSubmit={(e)=>{
                                            e.preventDefault()
                                            console.log(e.target[0].value)
                                            console.log(e.target[1].value)
                                            axios({
                                                method: 'get',
                                                url:'http://localhost:8000/sanctum/csrf-cookie',
                                                withCredentials:true,
                                                withXSRFToken:true,
                                            }).then(response => {
                                                console.log( response) 
                                            })
                                    
                                            axios({
                                                method: 'post',
                                                url:'http://localhost:8000/api/followups',
                                                withCredentials:true,
                                               headers:{
                                                'Content-Type':'application/json'
                                               },
                                               data: {
                                                lead_id: e.target[0].value,
                                                scheduled_at: e.target[1].value,
                                               },
                                                
                                            }).then(response => {
                                               
                                               toast("Follow up has been scheduled")
                                                console.log(response.data)
                                                
                                            }).catch(error => {
                                                alert(error.response.data.message)
                                            }) 
                                        }} >
                                <table  className="mx-auto table table-striped d-block d-sm-none">
                                <thead className="thead-dark ">
                                    <tr className="mx-auto">
                                        <th scope="col" className="text-light bg-secondary">Email</th>
                                        <th scope="col" className="text-light bg-secondary">Schedule</th>
                                    </tr>
                                </thead>
                                <tr>
                                    <input type="hidden" value={lead.id} name="lead_id" id="ead_id"/>
                                    <td><p>{lead.email}</p></td>
                                    <td><label>Schedule followup</label></td> 
                                </tr>
                                </table> <table className="mx-auto table table-striped d-block d-sm-none">
                                
                                <tr>
                                    <ToastContainer />
                                    <td><input type="datetime-local"  className="form-control" name="scheduled_at" id="scheduled_at"/></td> 
                                    <td>
                                        <button type="submit" className="btn d-flex btn-outline-dark align-items-center"
                                        
                                        >
                                            <img src="add.png" className="d-block" alt="add" width={20} height={20}/>
                                            submit
                                        </button>
                                    </td>                        
                                </tr>
                                </table>
                                
                                </form>  
                                    <hr/>
                                
                            </>
                           
                                
                            
                            
                        )
                    })}

                   

                   
                </>
            )}
            
           
            

        </div>
        )
}