import axios from "axios";
import { useEffect, useState } from "react"
import { toast, ToastContainer } from "react-toastify";
import Createlead from "./createlead";
import Leadlist from "./leadlist";
import Followlist from "./followlists";
import Createfollow from "./createfollow";


export default function Manager ({setPage}){
    useEffect(()=>{
        toast("You have succesfully logged in the system")
    }, [])

    const [ section, setSection] = useState(1);
    const [lsection , setLSection] =useState(1);


    return (
    <><ToastContainer />
        
        <div className="d-flex d-none d-sm-block min-vh-100">
                {/** Navigation for laptops*/}
                <div className="bg-secondary rounded  d-flex align-items-center justify-content-around">
                    <img src="Profile.png" alt="default profile pic -kalangeneexafront" className="rounded-circle mt-2" width={70} height={70}/>
                    <p className="text-light">Welcome name</p>

                    <hr style={{ borderColor:"white" }}/>
                    
                    <button className={lsection === 2 ? "d-flex btn btn-outline-dark active flex-row align-items-center justify-content-center  my-2" : "d-flex btn btn-outline-dark flex-row align-items-center justify-content-center  my-2"} onClick={()=>{setLSection(2)}}>
                        <img src="add.png" alt="Add lead-kalangeneexafront" className="d-block " width={20} height={20}/>
                        <p className={lsection === 2 ? "text-light my-auto mx-4": " my-auto mx-4"}>Create lead</p>
                    </button>
                    

                    <button className={lsection === 1 ? "d-flex btn btn-outline-dark active flex-row align-items-center justify-content-center  my-2": "d-flex btn btn-outline-dark flex-row align-items-center justify-content-center  my-2"} onClick={()=>{setLSection(1)}}>
                        <img src="list.png" alt="lead list-kalangeneexafront" className="d-block " width={20} height={20}/>
                        <p className={lsection === 1 ? "text-light my-auto mx-4": " my-auto mx-4"}>Lead  lists</p>
                    </button>

                   

                    <hr style={{ borderColor:"white" }}/>

                    <button className={lsection === 3 ?"d-flex btn btn-outline-dark active flex-row align-items-center justify-content-center  my-2" : "d-flex btn btn-outline-dark flex-row align-items-center justify-content-center  my-2"} onClick={()=>{setLSection(3)}}>
                        <img src="followuplist.png" alt="follow up list-kalangeneexafront" className="d-block " width={20} height={20}/>
                        <p className={lsection === 3 ? "text-light my-auto mx-4": " my-auto mx-4"}>Follow up list</p>
                    </button>

                    <button className={lsection === 4 ? "d-flex btn active btn-outline-dark flex-row align-items-center justify-content-center  my-2":"d-flex btn btn-outline-dark flex-row align-items-center justify-content-center  my-2" } onClick={()=>{setLSection(4)}}>
                        <img src="add.png" alt="Add lead-kalangeneexafront" className="d-block " width={20} height={20}/>
                        <p className={lsection === 4 ? "text-light my-auto mx-4": " my-auto mx-4"}>Add followup</p>
                    </button>

                    <hr style={{ borderColor:"white" }}/>
                    <button className="d-flex btn btn-danger flex-row align-items-center justify-content-center  my-2" onClick={()=>{
                        axios({
                            method: 'get',
                            url:'http://localhost:8000/sanctum/csrf-cookie',
                            withCredentials:true,
                            withXSRFToken:true,
                        }).then(response => {
                            console.log( response) 
                        })
                    
                        
                        axios({
                            method: 'post',
                            url:'http://localhost:8000/api/logout',
                            withCredentials:true,
                           headers:{
                            'Content-Type':'application/json'
                           },
                           
                        }).then(response => {
                           setPage(1)
                        }).catch(error => {
                            alert(error.response.data.message)
                        })
                    
                    }}>
                        <img src="logout.png" alt="Logout-kalangeneexafront" className="d-block " width={20} height={20}/>
                        <p className="text-light my-auto mx-3">Log out</p>
                    </button>

                </div>
                <div >
                    
                    {lsection ===1 ? (<Leadlist />): ""}
                    {lsection ===2 ? (<Createlead />): ""}
                    {lsection === 3 ? (<Followlist />) : ""}
                    {lsection === 4 ? (<Createfollow />) : ""}
                    
                </div>
                
            </div>
            
        

       
           

        {/** For mobile phones */}

        <div className=" d-block d-sm-none">
                {/** Navigation */}
                <div className="row  rounded d-flex flex-column align-items-center">
                    <div>
                        <img src="Profile.png" alt="default profile pic -kalangeneexafront" className="rounded-circle mt-2" width={70} height={70}/>
                        <p >Welcome name</p>
                    </div>
                    

                    <hr style={{ borderColor:"white" }}/>

                    <button className="d-flex btn btn-danger flex-row align-items-center justify-content-center  my-2" onClick={()=>{
                        axios({
                            method: 'get',
                            url:'http://localhost:8000/sanctum/csrf-cookie',
                            withCredentials:true,
                            withXSRFToken:true,
                        }).then(response => {
                            console.log( response) 
                        })
                    
                        
                        axios({
                            method: 'post',
                            url:'http://localhost:8000/api/logout',
                            withCredentials:true,
                           headers:{
                            'Content-Type':'application/json'
                           },
                           
                        }).then(response => {
                           setPage(1)
                        }).catch(error => {
                            alert(error.response.data.message)
                        })
                    
                    }}>
                        <img src="logout.png" alt="Logout-kalangeneexafront" className="d-block " width={20} height={20}/>
                        <p className="text-light my-auto mx-3">Log out</p>
                    </button>

                    <div className="d-flex">
                        <button className={section === 2 ? "d-flex btn flex-column btn-sm btn-outline-dark active flex-row align-items-center justify-content-center  my-2" : "d-flex flex-column btn btn-sm btn-outline-dark flex-row align-items-center justify-content-center  my-2"} onClick={()=>{setSection(2)}}>
                            <img src="add.png" alt="Add lead-kalangeneexafront" className="d-block " width={20} height={20}/>
                            <p className={section === 2 ? "text-light mx-2": " mx-2"}>Create lead</p>
                        </button>
                        

                        <button className={section === 1 ? "d-flex btn flex-column btn-sm btn-outline-dark active flex-row align-items-center justify-content-center  my-2": "d-flex flex-column btn btn-sm btn-outline-dark flex-row align-items-center justify-content-center  my-2"} onClick={()=>{setSection(1)}}>
                            <img src="list.png" alt="lead list-kalangeneexafront" className="d-block " width={20} height={20}/>
                            <p className={section === 1 ? "text-light  mx-2": "  mx-2"}>Lead  lists</p>
                        </button>

                    

                        <hr style={{ borderColor:"white" }}/>

                        <button className={section === 3 ?"d-flex btn flex-column btn-sm btn-outline-dark active flex-row align-items-center justify-content-center  my-2" : "d-flex btn flex-column btn-sm btn-outline-dark flex-row align-items-center justify-content-center  my-2"} onClick={()=>{setSection(3)}}>
                            <img src="followuplist.png" alt="follow up list-kalangeneexafront" className="d-block " width={20} height={20}/>
                            <p className={section === 3 ? "text-light  mx-2": "  mx-2"}>Follow up list</p>
                        </button>

                        <button className={section === 4 ? " flex-column d-flex btn btn-sm active btn-outline-dark flex-row align-items-center justify-content-center  my-2":"d-flex flex-column btn-sm btn btn-outline-dark flex-row align-items-center justify-content-center  my-2" } onClick={()=>{setSection(4)}}>
                            <img src="add.png" alt="Add lead-kalangeneexafront" className="d-block " width={20} height={20}/>
                            <p className={section === 4 ? "text-light  mx-2": "  mx-2"}>Add followup</p>
                        </button>


                    </div>
                    
                   
                    <hr style={{ borderColor:"white" }}/>
                    

                </div>

                <div className="row ">              
                    {section ===1 ? (<Leadlist />): ""}
                    {section ===2 ? (<Createlead />): ""}
                    {section === 3 ? (<Followlist />) : ""}
                    {section === 4 ? (<Createfollow />) : ""}
                    <hr />
                </div>
            </div>
    </>
    )
}