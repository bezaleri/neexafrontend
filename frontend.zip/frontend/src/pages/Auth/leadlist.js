import axios from "axios"
import { useEffect, useState } from "react"

export default function Leadlist (){

    const [ leads, setLeads] = useState([])

    useEffect(()=>{
        axios({
            method: 'get',
            url:'http://localhost:8000/sanctum/csrf-cookie',
            withCredentials:true,
            withXSRFToken:true,
        }).then(response => {
            console.log( response) 
        })

        axios({
            method: 'get',
            url:'http://localhost:8000/api/leads/all',
            withCredentials:true,
           headers:{
            'Content-Type':'application/json'
           },
            
        }).then(response => {
           
            setLeads(response.data)
            console.log(response.data)
            
        }).catch(error => {
            alert(error.response.data.message)
        })

    },[])


    return (
        <div>
            <h1> Lead list</h1>
            <hr />
            {leads.length === 0? (
                <div className="alert alert-danger" role="alert">
                    <p>Leads appear in the section bellow. Proceed to add a lead in the "Add lead Section "</p>
                </div>
                ): ( <table className="mx-auto table table-striped ">
                    <thead className="thead-dark">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">NAME</th>
                            <th scope="col">EMAIL</th>
                            <th scope="col">PHONE</th>
                        </tr>
                    </thead>

                    {leads.map(function(lead){
                        return (
                            <tr>
                                <td>{lead.id}</td>
                                <td>{lead.name} </td>
                                <td>{lead.email}</td>
                                <td>0{lead.phone}</td>
                                
                            </tr>
                        )
                    })}
                </table>
            )}
            
           
            

        </div>
        )
}