import { Alert } from "bootstrap";

export default function Homepage ({setPage}) {

    const viewlogin =()=> {
        setPage(1)
        localStorage.setItem('page', JSON.stringify(1))
    }

    const viewRegister = () => {
        setPage(2)
        localStorage.setItem('page', JSON.stringify(2))
    }
    const dummylink = () => {
        alert("This is a dummy link")
    }
    return (
    <>
    <div className="container-fluid">
        <header className="d-flex flex-row justify-content-between flex-wrap">
            <div className="d-flex flex-row align-items-center ml-4 ">
                <img src="transaction.png" alt="logo - kalangeneexafront" width={40} height={40} className="d-block my-3"/>
                <p className="h3 mx-2">Leads and follow ups </p>
            </div>

            <div className="d-flex flex-row align-items-center ml-4 ">
                <button  aria-pressed="true"  className="btn text-decoration-none my-2 mx-2"> Home</button>
                <button aria-pressed="true"  className="btn text-decoration-none my-2 mx-2" onClick={() => dummylink()}> Services</button>   
                <button aria-pressed="true"  className="btn text-decoration-none my-2 mx-2" onClick={() => dummylink()}> About</button>
                
            </div>

            <div className="d-flex flex-row align-items-center ml-4 ">
                <button aria-pressed="true"  className="btn btn-primary " onClick={()=>viewlogin()}> Login</button>
            </div>
        </header>

        <div className="position-relative">
            <img src="business-woman.jpg" className="img-fluid opacity-25" alt="home page lead - kalangeneexafront" />
            <div className="position-absolute top-50 start-50 translate-middle ">
                <p className="h1  ">Create lead and follow up</p>
                <p className="">Get access to many potential customers and grow your business</p>
                <button aria-pressed="true"  className="btn btn-outline-dark btn-lg" onClick={()=>viewRegister()}> Get Started</button>
            </div>
        </div>

    </div>

    <div className="container">
        <div style={{ maxWidth:'75%' }} className="mx-auto my-2 p-2 bg-light">
            <p className="h5">Lead Capture and Management</p>
            <p>The software captures leads from various sources, such as websites, social media, landing pages, and email campaigns, and consolidates them into single organized database. It tracks essential lead information, including contact details, source and engagement history ensuring no lead is lost</p>
        </div>
        <div style={{ maxWidth:'75%' }} className="mx-auto my-2 p-2 bg-light">
            <p className="h5">Lead Scoring and segmentation</p>
            <p>Leads are scored on criteria such as engagement, demographics and interactions, This scoring helps prioritize leads for follow ups and target them with relevant content or offers.Segmentation further categorizes leads based on criteria such as behavior, demographics or lifecycle stage</p>
        </div>
        
    </div>
    <div className="container-fluid">
        <hr></hr>
        <div>
            <p>Copyright @ kalangeneexafront 2024</p>
        </div>
    </div>
    
    </>
    );
}

