import axios from "axios"
import { useState } from "react"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function Registerpage({setPage}){

    const [name, setName] = useState("")
    const [email , setEmail] = useState("")
    const [password, setPassword] = useState('')
    const [confirmpassword , setconfirmpassword]= useState('')
    const [role, setRole] = useState("Sales Rep")
    
    
    
    const submit = () => {

        axios({
            method: 'get',
            url:'http://localhost:8000/sanctum/csrf-cookie',
            withCredentials:true,
            withXSRFToken:true,
        }).then(response => {
            console.log( response) 
        })

        axios({
            method: 'post',
            url:'http://localhost:8000/api/customregister',
            withCredentials:true,
           headers:{
            'Content-Type':'application/json'
           },
            data: JSON.stringify({
                name: name,
                password: password,
                confirmpassword: password,
                email: email,
                role: role,
            })
        }).then(response => {
           
            setPage(3)
            localStorage.setItem('page', JSON.stringify(3))
            toast("You have successfully logged into the system")
        }).catch(error => {
            alert(error.response.data.message)
        })



    }

    const tologin =() => {
        setPage(1)
        localStorage.setItem('page', JSON.stringify(1))
    }
    return (
        <>
        <div className="min-vh-100 d-flex flex-column d-none d-sm-block" style={{ backgroundColor:'blanchedalmond' }}>
            <ToastContainer />
            <div className="my-2 mx-5 d-flex flex-row" >
                <button className="btn btn-outline-light d-block btn-lg mr-3" onClick={()=>{setPage(0); localStorage.setItem('page', JSON.stringify(0))}} >Home</button>
            </div>
            
            <div className="w-50 mx-auto my-auto bg-light rounded shadow-lg" >
            <img src="transaction.png" alt="our logo - kalangeneexafront"  className="d-block mx-auto my-3" width={70} height={70}/>
            <p className="h3">Register</p>
                <table  className="mx-auto" style={{ borderCollapse:'separate' , borderSpacing:'1em' }}>

                    <tr className="mt-3 form-group">
                            
                            <td className="text-end">
                                <label htmlFor="username" className="text-end" >Name</label>
                            </td>
                        <td> 
                                <input type="text" id="username" className="form-control"  value={name} onChange={(e) => {
                                    setName(e.target.value)
                                }}/>
                        </td>                    
                    
                    </tr>

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end">
                                <label htmlFor="useremail"  >Email</label>
                            </td>
                            <td>
                                <input type="email" id="useremail" className="form-control" value={email}  onChange={(e) => {
                                    setEmail(e.target.value)
                                }}/>
                            </td>
                        
                    </tr>

                

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end">
                                <label htmlFor="password" >Password</label>
                            </td>
                            <td>
                                <input type="password" id="password" className="form-control" value={password} onChange={(e) => {
                                    setPassword(e.target.value)
                                }} />
                            </td>
                            
                        
                    </tr>

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end my-5"><label htmlFor="confirmpassword"  value={confirmpassword} onChange={(e) => {setconfirmpassword(e.target.value)}}>Confirm Password</label></td>
                            <td><input type="password" id="confirmpassword" className="form-control" /></td>
                        
                    </tr>

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end">
                                <label htmlFor="role" >Role</label>
                            </td>
                            <td>
                                <select aria-label="role select" className="form-select" value={role} onChange={(e) => setRole(e.target.value)}>
                                    <option value={"Sales Rep"}>Sales Rep</option>
                                    <option value={"Sales Manager"}>Sales Manager</option>
                                    <option value={"Admin"}>Admin</option>
                                    
                                    
                                </select>
                            </td>
                            
                        
                    </tr>

                    <tr className="mt-3 form-group">
                        <td></td>
                        <td><button type="submit" className="btn btn-primary btn-lg" onClick={()=> submit()}>Register</button></td>
                    </tr>
                </table>
                <p>Already have an account? <button className="btn btn-link" onClick={() => tologin()} >Login</button></p>
            </div>
           

        </div>

        {/**Devices that are phones and lower */}


        <div className="min-vh-100 d-flex flex-column d-block d-sm-none" style={{ backgroundColor:'blanchedalmond' }}>
            <ToastContainer />
            <div className="my-2 mx-5 d-flex flex-row" >
                <button className="btn btn-outline-light d-block btn-lg mr-3" onClick={()=>{setPage(0); localStorage.setItem('page', JSON.stringify(0))}} >Home</button>
            </div>
            
            <div className="w-100 mx-auto my-auto bg-light rounded shadow-lg" >
            <img src="transaction.png" alt="our logo - kalangeneexafront"  className="d-block mx-auto my-3" width={70} height={70}/>
            <p className="h3">Register</p>
                <table  className="mx-auto" style={{ borderCollapse:'separate' , borderSpacing:'1em' }}>

                    <tr className="mt-3 form-group">
                            
                            <td className="text-end">
                                <label htmlFor="username" className="text-end" >Name</label>
                            </td>
                        <td> 
                                <input type="text" id="username" className="form-control"  value={name} onChange={(e) => {
                                    setName(e.target.value)
                                }}/>
                        </td>                    
                    
                    </tr>

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end">
                                <label htmlFor="useremail"  >Email</label>
                            </td>
                            <td>
                                <input type="email" id="useremail" className="form-control" value={email}  onChange={(e) => {
                                    setEmail(e.target.value)
                                }}/>
                            </td>
                        
                    </tr>

                

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end">
                                <label htmlFor="password" >Password</label>
                            </td>
                            <td>
                                <input type="password" id="password" className="form-control" value={password} onChange={(e) => {
                                    setPassword(e.target.value)
                                }} />
                            </td>
                            
                        
                    </tr>

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end my-5"><label htmlFor="confirmpassword"  value={confirmpassword} onChange={(e) => {setconfirmpassword(e.target.value)}}>Confirm Password</label></td>
                            <td><input type="password" id="confirmpassword" className="form-control" /></td>
                        
                    </tr>

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end">
                                <label htmlFor="role" >Role</label>
                            </td>
                            <td>
                                <select aria-label="role select" className="form-select" value={role} onChange={(e) => setRole(e.target.value)}>
                                    <option value={"Sales Rep"}>Sales Rep</option>
                                    <option value={"Sales Manager"}>Sales Manager</option>
                                    <option value={"Admin"}>Admin</option>
                                    
                                    
                                </select>
                            </td>
                            
                        
                    </tr>

                    <tr className="mt-3 form-group">
                        <td></td>
                        <td><button type="submit" className="btn btn-primary btn-lg" onClick={()=> submit()}>Register</button></td>
                    </tr>
                </table>
                <p>Already have an account? <button className="btn btn-link" onClick={() => tologin()} >Login</button></p>
            </div>
           

        </div>
        </>
    )
}