import axios from "axios"
import { useState } from "react"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function Loginpage ({setPage}){

   const toregister =() => {
      setPage(2)
      localStorage.setItem('page', JSON.stringify(2))
   }


   const [email , setEmail] = useState("")
   const [password, setPassword] = useState('')


   const submit = () => {

    axios({
        method: 'get',
        url:'http://localhost:8000/sanctum/csrf-cookie',
        withCredentials:true,
        withXSRFToken:true,
    }).then(response => {
        console.log( response) 
    })

    
    axios({
        method: 'post',
        url:'http://localhost:8000/api/customlogin',
        withCredentials:true,
       headers:{
        'Content-Type':'application/json'
       },
        data: JSON.stringify({
            password: password,
            email: email,
        })
    }).then(response => {
        console.log( response) 
        setPage(3)
        localStorage.setItem('page', JSON.stringify(3))
        toast("You have successfully logged into the system")
    }).catch(error => {
        alert(error.response.data.message)
    })



}

 return (
    <>
    <div className="min-vh-100 d-none d-sm-block  d-flex flex-column" style={{ backgroundColor:'blanchedalmond' }}>
        <ToastContainer />
            <div className="my-2 mx-5 d-flex flex-row" >
                  <button className="btn btn-outline-light d-block btn-lg mr-3" onClick={()=>{setPage(0); localStorage.setItem('page', JSON.stringify(0))}} >Home</button>
            </div>

            <div className="w-50 mx-auto my-auto bg-light rounded shadow-lg">
            <img src="transaction.png" alt="our logo - kalangeneexafront"  className="d-block mx-auto my-3" width={70} height={70}/>
            <p className="h3">Login</p>
                <table  className="mx-auto" style={{ borderCollapse:'separate' , borderSpacing:'1em' }}>

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end">
                                <label htmlFor="useremail"  >Email</label>
                            </td>
                            <td>
                                <input type="email" id="useremail" className="form-control" value={email} onChange={(e)=>{
                                    setEmail(e.target.value)
                                }}/>
                            </td>
                        
                    </tr>

                

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end">
                                <label htmlFor="password" >Password</label>
                            </td>
                            <td>
                                <input type="password" id="password" className="form-control" value={password} onChange={(e) => {
                                    setPassword(e.target.value)
                                }} />
                            </td>
                            
                        
                    </tr>

                   

                    <tr className="mt-3 form-group">
                        <td></td>
                        <td><button type="submit" className="btn btn-primary btn-lg" onClick={()=> {submit()}}>Login</button></td>
                    </tr>
                </table>
                <p>Don't have an account? <button className="btn btn-link" onClick={()=> toregister()}>Register</button></p>
            </div>
           

        </div>

                                {/** Visible on only phones downwards */}
        <div className="min-vh-100  d-flex flex-column d-block d-sm-none" style={{ backgroundColor:'blanchedalmond' }}>
        <ToastContainer />
            <div className="my-2 mx-5 d-flex flex-row" >
                  <button className="btn btn-outline-light d-block btn-lg mr-3" onClick={()=>{setPage(0); localStorage.setItem('page', JSON.stringify(0))}} >Home</button>
            </div>

            <div className="w-100 mx-auto my-auto bg-light rounded shadow-lg">
            <img src="transaction.png" alt="our logo - kalangeneexafront"  className="d-block mx-auto my-3" width={70} height={70}/>
            <p className="h3">Login</p>
                <table  className="mx-auto" style={{ borderCollapse:'separate' , borderSpacing:'1em' }}>

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end">
                                <label htmlFor="useremail"  >Email</label>
                            </td>
                            <td>
                                <input type="email" id="useremail" className="form-control" value={email} onChange={(e)=>{
                                    setEmail(e.target.value)
                                }}/>
                            </td>
                        
                    </tr>

                

                    <tr className="mt-3 form-group">
                        
                            <td className="text-end">
                                <label htmlFor="password" >Password</label>
                            </td>
                            <td>
                                <input type="password" id="password" className="form-control" value={password} onChange={(e) => {
                                    setPassword(e.target.value)
                                }} />
                            </td>
                            
                        
                    </tr>

                   

                    <tr className="mt-3 form-group">
                        <td></td>
                        <td><button type="submit" className="btn btn-primary btn-lg" onClick={()=> {submit()}}>Login</button></td>
                    </tr>
                </table>
                <p>Don't have an account? <button className="btn btn-link" onClick={()=> toregister()}>Register</button></p>
            </div>
           

        </div>
    </>
 )
}