import { useEffect, useState } from 'react';
import './App.css';
import Homepage from './pages/homepage';
import Loginpage from './pages/loginpage';
import Registerpage from './pages/registerpage';
import Manager from './pages/Auth/manager';
import axios from 'axios';

function App() {
  
  axios.defaults.withCredentials=true
  axios.defaults.withXSRFToken = true
  const [page , setPage] = useState(0);

 

  

  return (
    <div className="App">
      {page===0 ? (<Homepage setPage={setPage}/>):(<></>) /**Default page / HomePage  */}
      {page===1 ? (<Loginpage setPage={setPage}/>):(<></>) /**Login Page */}
      {page===2 ? (<Registerpage setPage={setPage}/>):(<></>) /**Registser Page */}
      {page===3 ? (<Manager setPage={setPage}/>):(<></>) /**Registser Page */}
      
      
    </div>
  );
}

export default App;
