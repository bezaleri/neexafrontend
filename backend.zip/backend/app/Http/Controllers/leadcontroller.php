<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use App\Models\User;
use Illuminate\Http\Request;

class leadcontroller extends Controller
{
    //

    public function create (Request $request){
        $request->validate(
            [
                'name' => ['required', 'string', 'max:255'],
                'email' => [
                    'required',
                    'string',
                    'email',
                    'max:255',
                    'unique:users,email',
                   
                ],
                'phone' => ['required',  'min:10'],]
        );
   
         Lead::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'phone' =>  $request['phone'],
        ]);
    }

    public function retrieveall ( User $user){
        return response()->json(Lead::all());
    }
}
