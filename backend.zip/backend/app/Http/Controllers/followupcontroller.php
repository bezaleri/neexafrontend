<?php

namespace App\Http\Controllers;

use App\Models\Followup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class followupcontroller extends Controller
{
    //
    
    public function create (Request $request){
        $request->validate(
            [
                'lead_id' => ['required', 'integer', 'max:255'],
                
                'scheduled_at' => ['required',  'date' ,'after:now' ],]
        );
   
         Followup::create([
            'lead_id' => $request['lead_id'],
            'scheduled_at' => $request['scheduled_at'],
            'status' => "Pending",
        ]);
    }

    public function retrieveall (){
        return response()->json(DB::table('leads')->join('followups', 'leads.id' , '=','followups.lead_id')->get());
    }
    public function update (Request $request , $id){

    }
}
