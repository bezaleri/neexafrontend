<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class customlogincontroller extends Controller
{
    //

    public function create(Request $request)
    
    {
        $validated = $request->validate(
            [
                'email' => [
                    'required',
                    'string',
                    'email',
                    'max:255',                   
                ],
                'password' => ['required', 'min:8'],]
        );
        
    

        if (Auth::attempt($validated)) {
            $request->session()->regenerate();
 
            return response() -> json(['redirect' => 'dashboard']);
        }
    }
}
