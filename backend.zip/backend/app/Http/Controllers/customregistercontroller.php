<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class customregistercontroller extends Controller
{
    //
    public function create(Request $request)
    
    {
        $request->validate(
            [
                'name' => ['required', 'string', 'max:255'],
                'email' => [
                    'required',
                    'string',
                    'email',
                    'max:255',
                    'unique:users,email',
                   
                ],
                'password' => ['required', 'min:8'],
                'role' => ['required' , 'string'],
            ],
                
        );
    
         User::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'role' => $request['role'],
            'password' => Hash::make($request['password']),
        ]);
 
        return response() -> json(['redirect' => 'tologinsfully']);
        
    }
}
