<?php


use App\Http\Controllers\customlogincontroller;
use App\Http\Controllers\customregistercontroller;
use App\Http\Controllers\followupcontroller;
use App\Http\Controllers\leadcontroller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/customregister', [customregistercontroller::class, 'create']);
Route::post('/customlogin' , [customlogincontroller::class , 'create']);

Route::post('/leads', [leadcontroller::class , 'create']);
Route::get('/leads/all', [leadcontroller::class, 'retrieveall']);
Route::post('/followups', [followupcontroller::class , 'create']);
Route::get('/followups/all', [followupcontroller::class, 'retrieveall']);
Route::post('/followups/{id}/status', [followupcontroller::class , 'update']);

Route:: post ('/logout' , function (Request $request){
    Auth::logout();
    $request->session()->invalidate();
 
    $request->session()->regenerateToken();
});

